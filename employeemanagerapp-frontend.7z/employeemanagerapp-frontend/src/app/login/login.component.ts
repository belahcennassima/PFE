import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ChartConfiguration, ChartData } from 'chart.js';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: string = '';
  password: string = '';
  errorMessage: string = '';
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    if (this.authService.isLoggedIn()) {
      this.redirectBasedOnRole();
    }
  }

  onLogin(): void {
    if (!this.username || !this.password) {
      this.errorMessage = 'Veuillez entrer votre nom d\'utilisateur et mot de passe';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    this.authService.login(this.username, this.password).subscribe(
      (response) => {
        this.isLoading = false;
        if (response.success) {
          this.redirectBasedOnRole();
        } else {
          this.errorMessage = response.message || 'Échec de connexion';
        }
      },
      (error: HttpErrorResponse) => {
        this.isLoading = false;
        this.errorMessage = 'Nom d\'utilisateur ou mot de passe invalide';
      }
    );
  }

  private redirectBasedOnRole(): void {
    if (this.authService.isHR()) {
      this.router.navigate(['/hr-dashboard']);
    } else if (this.authService.isUser()) {
      this.router.navigate(['/user-dashboard']);
    } else {
      this.router.navigate(['/login']);
    }
  }
}