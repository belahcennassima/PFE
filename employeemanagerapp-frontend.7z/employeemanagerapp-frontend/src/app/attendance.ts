export interface Attendance {
  id?: number;
  employeeId: number;
  date: string;
  status: string; // 'PRESENT', 'ABSENT', 'CONGE', 'MALADIE'
  checkInTime?: string;
  checkOutTime?: string;
  notes?: string;
}