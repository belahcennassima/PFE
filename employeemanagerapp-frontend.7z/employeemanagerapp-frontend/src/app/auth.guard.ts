import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private authService: AuthService
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const currentUser = this.authService.currentUserValue;
    const isAuthenticated = this.authService.isLoggedIn(); // Utilisez isLoggedIn() au lieu de isAuthenticated
    
    if (currentUser && isAuthenticated) {
      // Vérifier le rôle si nécessaire
      if (route.data.role) {
        const userRole = currentUser.role;
        if (userRole !== route.data.role) {
          console.log('Access denied: wrong role');
          this.router.navigate(['/login']);
          return false;
        }
      }
      return true;
    }

    // Pas connecté, rediriger vers login
    console.log('Not authenticated, redirecting to login');
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
}