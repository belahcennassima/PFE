import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { User, AuthResponse } from './user';
import { Employee } from './employee';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiServerUrl = environment.apiBaseUrl;
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;
  private currentEmployeeSubject: BehaviorSubject<Employee | null>;
  public currentEmployee: Observable<Employee | null>;

  constructor(private http: HttpClient) {
    const storedUser = localStorage.getItem('currentUser');
    const storedEmployee = localStorage.getItem('currentEmployee');
    
    this.currentUserSubject = new BehaviorSubject<User | null>(
      storedUser ? JSON.parse(storedUser) : null
    );
    this.currentUser = this.currentUserSubject.asObservable();
    
    this.currentEmployeeSubject = new BehaviorSubject<Employee | null>(
      storedEmployee ? JSON.parse(storedEmployee) : null
    );
    this.currentEmployee = this.currentEmployeeSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public get currentEmployeeValue(): Employee | null {
    return this.currentEmployeeSubject.value;
  }

  public login(username: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiServerUrl}/api/auth/login`, { username, password })
      .pipe(
        tap(response => {
          if (response.success && response.user) {
            localStorage.setItem('currentUser', JSON.stringify(response.user));
            this.currentUserSubject.next(response.user);
            
            if (response.employee) {
              localStorage.setItem('currentEmployee', JSON.stringify(response.employee));
              this.currentEmployeeSubject.next(response.employee);
            }
          }
        })
      );
  }

  public logout(): void {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('currentEmployee');
    this.currentUserSubject.next(null);
    this.currentEmployeeSubject.next(null);
  }

  public isLoggedIn(): boolean {
    return this.currentUserValue !== null;
  }

  public isHR(): boolean {
    return this.currentUserValue?.role === 'HR';
  }

  public isUser(): boolean {
    return this.currentUserValue?.role === 'USER';
  }
}