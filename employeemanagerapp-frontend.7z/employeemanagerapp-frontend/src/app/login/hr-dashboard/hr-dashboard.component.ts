import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Employee } from '../../employee';
import { Attendance } from '../../attendance';
import { LeaveRequest } from '../../leave-request';
import { EmployeeService } from '../../employee.service';
import { AttendanceService } from '../../attendance.service';
import { LeaveRequestService } from '../../leave-request.service';
import { AuthService } from '../../auth.service';
import { ThemeService } from '../../theme.service';
import { ToastrService } from 'ngx-toastr';
import { ChartConfiguration, ChartData } from 'chart.js';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

@Component({
  selector: 'app-hr-dashboard',
  templateUrl: './hr-dashboard.component.html',
  styleUrls: ['./hr-dashboard.component.css']
})
export class HrDashboardComponent implements OnInit {
  public employees: Employee[] = [];
  public attendances: Attendance[] = [];
  public leaveRequests: LeaveRequest[] = [];
  public pendingLeaveRequests: LeaveRequest[] = [];
  public editEmployee: Employee | undefined;
  public deleteEmployee: Employee | undefined;
  public selectedLeaveRequest: LeaveRequest | undefined;
  
  public selectedEmployee: Employee | undefined;
  public newAttendance: Attendance = {
    employeeId: 0,
    date: '',
    status: 'PRESENT'
  };
  
  public allEmployees: Employee[] = [];
  public isDarkMode: boolean = false;
  
  // Statistiques globales
  public totalEmployees: number = 0;
  public totalPresentToday: number = 0;
  public totalAbsentToday: number = 0;
  public pendingLeaveCount: number = 0;
  
  // Configuration du graphique
  public chartData: ChartData = {
    labels: [],
    datasets: [{
      label: 'Heures travaillées',
      data: [],
      backgroundColor: '#007bff'
    }]
  };
  
  public chartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  };

  constructor(
    private employeeService: EmployeeService,
    private attendanceService: AttendanceService,
    private leaveRequestService: LeaveRequestService,
    private authService: AuthService,
    private themeService: ThemeService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit() {
    this.themeService.darkMode$.subscribe(isDark => {
      this.isDarkMode = isDark;
    });
    
    this.loadAllData();
  }

  loadAllData(): void {
    this.getEmployees();
    this.getAllAttendances();
    this.getAllLeaveRequests();
    this.getPendingLeaveRequests();
  }

  public getEmployees(): void {
    this.employeeService.getEmployees().subscribe(
      (response: Employee[]) => {
        this.employees = response;
        this.allEmployees = response;
        this.totalEmployees = response.length;
        //this.updateEmployeeChart();
        this.toastr.success('Employés chargés', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors du chargement des employés', 'Erreur');
      }
    );
  }

  public getAllAttendances(): void {
    this.attendanceService.getAllAttendances().subscribe(
      (response: Attendance[]) => {
        this.attendances = response.sort((a, b) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        );
        this.calculateTodayStats();
        this.updateEmployeeChart();
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors du chargement des présences', 'Erreur');
      }
    );
  }

  public getAllLeaveRequests(): void {
    this.leaveRequestService.getAllLeaveRequests().subscribe(
      (response: LeaveRequest[]) => {
        this.leaveRequests = response.sort((a, b) => 
          new Date(b.startDate).getTime() - new Date(a.startDate).getTime()
        );
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors du chargement des demandes', 'Erreur');
      }
    );
  }

  public getPendingLeaveRequests(): void {
    this.leaveRequestService.getPendingLeaveRequests().subscribe(
      (response: LeaveRequest[]) => {
        this.pendingLeaveRequests = response;
        this.pendingLeaveCount = response.length;
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors du chargement', 'Erreur');
      }
    );
  }

  calculateTodayStats(): void {
    const today = new Date().toISOString().split('T')[0];
    this.totalPresentToday = this.attendances.filter(a => 
      a.date === today && a.status === 'PRESENT'
    ).length;
    this.totalAbsentToday = this.attendances.filter(a => 
      a.date === today && a.status === 'ABSENT'
    ).length;
  }

  updateEmployeeChart(): void {
    const employeeNames: string[] = [];
    const employeeHours: number[] = [];
    
    this.employees.slice(0, 10).forEach(emp => {
      const empAttendances = this.attendances.filter(a => a.employeeId === emp.id);
      let totalHours = 0;
      
      empAttendances.forEach(att => {
        if (att.checkInTime && att.checkOutTime) {
          totalHours += this.calculateHours(att.checkInTime, att.checkOutTime);
        }
      });
      
      employeeNames.push(emp.name.split(' ')[0]);
      employeeHours.push(totalHours);
    });
    
    this.chartData = {
      labels: employeeNames,
      datasets: [{
        label: 'Heures travaillées',
        data: employeeHours,
        backgroundColor: '#007bff'
      }]
    };
  }

  calculateHours(checkIn: string, checkOut: string): number {
    const [inHours, inMinutes] = checkIn.split(':').map(Number);
    const [outHours, outMinutes] = checkOut.split(':').map(Number);
    
    const inTotalMinutes = inHours * 60 + inMinutes;
    const outTotalMinutes = outHours * 60 + outMinutes;
    
    return (outTotalMinutes - inTotalMinutes) / 60;
  }

  public onOpenModal(employee: Employee | null, mode: string): void {
    const container = document.getElementById('main-container');
    const button = document.createElement('button');
    button.type = 'button';
    button.style.display = 'none';
    button.setAttribute('data-toggle', 'modal');
    
    if (mode === 'add') {
      button.setAttribute('data-target', '#addEmployeeModal');
    }
    if (mode === 'edit') {
      this.editEmployee = employee!;
      button.setAttribute('data-target', '#updateEmployeeModal');
    }
    if (mode === 'delete') {
      this.deleteEmployee = employee!;
      button.setAttribute('data-target', '#deleteEmployeeModal');
    }
    if (mode === 'attendance') {
      this.selectedEmployee = employee!;
      this.newAttendance.employeeId = employee!.id;
      this.newAttendance.date = '';
      this.newAttendance.status = 'PRESENT';
      this.newAttendance.checkInTime = '';
      this.newAttendance.checkOutTime = '';
      this.newAttendance.notes = '';
      button.setAttribute('data-target', '#addAttendanceModal');
    }
    
    container?.appendChild(button);
    button.click();
  }

  public onOpenLeaveModal(request: LeaveRequest): void {
    this.selectedLeaveRequest = request;
    const button = document.createElement('button');
    button.type = 'button';
    button.style.display = 'none';
    button.setAttribute('data-toggle', 'modal');
    button.setAttribute('data-target', '#leaveRequestModal');
    document.getElementById('main-container')?.appendChild(button);
    button.click();
  }

  public onAddEmployee(addForm: any): void {
    document.getElementById('add-employee-form')?.click();
    this.employeeService.addEmployee(addForm.value).subscribe(
      (response: Employee) => {
        this.getEmployees();
        addForm.reset();
        this.toastr.success('Employé ajouté avec succès', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors de l\'ajout', 'Erreur');
        addForm.reset();
      }
    );
  }

  public onUpdateEmployee(employee: Employee): void {
    this.employeeService.updateEmployee(employee).subscribe(
      (response: Employee) => {
        this.getEmployees();
        this.toastr.success('Employé modifié avec succès', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors de la modification', 'Erreur');
      }
    );
  }

  public onDeleteEmployee(employeeId: number): void {
    this.employeeService.deleteEmployee(employeeId).subscribe(
      (response: void) => {
        this.getEmployees();
        this.getAllAttendances();
        this.toastr.success('Employé supprimé avec succès', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors de la suppression', 'Erreur');
      }
    );
  }

  public onAddAttendance(attendanceForm: any): void {
    document.getElementById('add-attendance-form')?.click();
    this.attendanceService.addAttendance(this.newAttendance).subscribe(
      (response: Attendance) => {
        this.getAllAttendances();
        this.newAttendance = {
          employeeId: 0,
          date: '',
          status: 'PRESENT'
        };
        attendanceForm.reset();
        this.toastr.success('Présence ajoutée avec succès', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors de l\'ajout', 'Erreur');
      }
    );
  }

  public approveLeaveRequest(): void {
    if (this.selectedLeaveRequest) {
      this.selectedLeaveRequest.status = 'APPROVED';
      this.leaveRequestService.updateLeaveRequest(this.selectedLeaveRequest).subscribe(
        (response: LeaveRequest) => {
          this.getAllLeaveRequests();
          this.getPendingLeaveRequests();
          document.getElementById('close-leave-modal')?.click();
          this.toastr.success('Demande approuvée', 'Succès');
        },
        (error: HttpErrorResponse) => {
          this.toastr.error('Erreur', 'Erreur');
        }
      );
    }
  }

  public rejectLeaveRequest(): void {
    if (this.selectedLeaveRequest) {
      this.selectedLeaveRequest.status = 'REJECTED';
      this.leaveRequestService.updateLeaveRequest(this.selectedLeaveRequest).subscribe(
        (response: LeaveRequest) => {
          this.getAllLeaveRequests();
          this.getPendingLeaveRequests();
          document.getElementById('close-leave-modal')?.click();
          this.toastr.warning('Demande rejetée', 'Info');
        },
        (error: HttpErrorResponse) => {
          this.toastr.error('Erreur', 'Erreur');
        }
      );
    }
  }

  public getEmployeeName(employeeId: number): string {
    const employee = this.allEmployees.find(e => e.id === employeeId);
    return employee ? employee.name : 'Unknown';
  }

  public getStatusBadgeClass(status: string): string {
    switch(status) {
      case 'PRESENT': return 'badge-success';
      case 'ABSENT': return 'badge-danger';
      case 'CONGE': return 'badge-warning';
      case 'MALADIE': return 'badge-info';
      case 'PENDING': return 'badge-warning';
      case 'APPROVED': return 'badge-success';
      case 'REJECTED': return 'badge-danger';
      default: return 'badge-secondary';
    }
  }

  public getLeaveTypeLabel(type: string): string {
    switch(type) {
      case 'ANNUAL': return 'Congé annuel';
      case 'SICK': return 'Congé maladie';
      case 'UNPAID': return 'Congé sans solde';
      default: return type;
    }
  }

  public searchEmployees(key: string): void {
    const results: Employee[] = [];
    for (const employee of this.allEmployees) {
      if (employee.name.toLowerCase().indexOf(key.toLowerCase()) !== -1
      || employee.email.toLowerCase().indexOf(key.toLowerCase()) !== -1
      || employee.phone.toLowerCase().indexOf(key.toLowerCase()) !== -1
      || employee.jobTitle.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
        results.push(employee);
      }
    }
    this.employees = results;
    if (results.length === 0 || !key) {
      this.employees = this.allEmployees;
    }
  }

  exportAllToPDF(): void {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text('Rapport Complet des Présences', 14, 22);
    
    const tableData = this.attendances.map(att => [
      this.getEmployeeName(att.employeeId),
      att.date,
      att.status,
      att.checkInTime || '-',
      att.checkOutTime || '-'
    ]);
    
    (doc as any).autoTable( {
      startY: 30,
      head: [['Employé', 'Date', 'Statut', 'Entrée', 'Sortie']],
      body: tableData
    });
    
    doc.save('rapport_presences_complet.pdf');
    this.toastr.success('PDF exporté', 'Export');
  }

  exportAllToExcel(): void {
    const worksheet = XLSX.utils.json_to_sheet(
      this.attendances.map(att => ({
        'Employé': this.getEmployeeName(att.employeeId),
        'Date': att.date,
        'Statut': att.status,
        'Heure Entrée': att.checkInTime || '-',
        'Heure Sortie': att.checkOutTime || '-',
        'Notes': att.notes || '-'
      }))
    );
    
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Présences');
    
    XLSX.writeFile(workbook, 'rapport_presences_complet.xlsx');
    this.toastr.success('Excel exporté', 'Export');
  }

  toggleTheme(): void {
    this.themeService.toggleTheme();
  }

  public logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}