import { Employee } from './employee';

export interface User {
  id: number;
  username: string;
  password?: string;
  email: string;
  role: string; // 'USER' ou 'HR'
  employeeId?: number;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user: User;
  employee?: Employee;
}