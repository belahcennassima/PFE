import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor() { }

  /**
   * Afficher une notification de succès
   */
  success(message: string, title: string = 'Succès'): void {
    this.showNotification(message, title, 'success');
  }

  /**
   * Afficher une notification d'erreur
   */
  error(message: string, title: string = 'Erreur'): void {
    this.showNotification(message, title, 'error');
  }

  /**
   * Afficher une notification d'avertissement
   */
  warning(message: string, title: string = 'Attention'): void {
    this.showNotification(message, title, 'warning');
  }

  /**
   * Afficher une notification d'information
   */
  info(message: string, title: string = 'Information'): void {
    this.showNotification(message, title, 'info');
  }

  /**
   * Créer et afficher une notification personnalisée
   */
  private showNotification(message: string, title: string, type: string): void {
    // Créer le conteneur de notification
    const notification = document.createElement('div');
    notification.className = `custom-notification ${type}`;
    
    // Créer le HTML de la notification
    notification.innerHTML = `
      <div class="notification-header">
        <i class="notification-icon fa ${this.getIcon(type)}"></i>
        <strong>${title}</strong>
        <button class="notification-close" onclick="this.parentElement.parentElement.remove()">&times;</button>
      </div>
      <div class="notification-body">
        ${message}
      </div>
      <div class="notification-progress"></div>
    `;
    
    // Ajouter la notification au DOM
    document.body.appendChild(notification);
    
    // Animation d'entrée
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);
    
    // Supprimer automatiquement après 4 secondes
    setTimeout(() => {
      notification.classList.remove('show');
      notification.classList.add('hide');
      setTimeout(() => {
        if (notification.parentElement) {
          document.body.removeChild(notification);
        }
      }, 300);
    }, 4000);
  }

  /**
   * Obtenir l'icône Font Awesome selon le type
   */
  private getIcon(type: string): string {
    switch(type) {
      case 'success': return 'fa-check-circle';
      case 'error': return 'fa-times-circle';
      case 'warning': return 'fa-exclamation-triangle';
      case 'info': return 'fa-info-circle';
      default: return 'fa-bell';
    }
  }

  /**
   * Afficher une confirmation avec callback
   */
  confirm(message: string, onConfirm: () => void, onCancel?: () => void): void {
    const overlay = document.createElement('div');
    overlay.className = 'confirmation-overlay';
    
    overlay.innerHTML = `
      <div class="confirmation-dialog">
        <div class="confirmation-header">
          <i class="fa fa-question-circle"></i>
          <h4>Confirmation</h4>
        </div>
        <div class="confirmation-body">
          <p>${message}</p>
        </div>
        <div class="confirmation-footer">
          <button class="btn btn-secondary confirm-cancel">Annuler</button>
          <button class="btn btn-primary confirm-ok">Confirmer</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(overlay);
    
    // Animation d'entrée
    setTimeout(() => overlay.classList.add('show'), 10);
    
    // Bouton Confirmer
    const okButton = overlay.querySelector('.confirm-ok') as HTMLElement;
    okButton.addEventListener('click', () => {
      overlay.classList.remove('show');
      setTimeout(() => document.body.removeChild(overlay), 300);
      onConfirm();
    });
    
    // Bouton Annuler
    const cancelButton = overlay.querySelector('.confirm-cancel') as HTMLElement;
    cancelButton.addEventListener('click', () => {
      overlay.classList.remove('show');
      setTimeout(() => document.body.removeChild(overlay), 300);
      if (onCancel) onCancel();
    });
    
    // Cliquer en dehors pour fermer
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('show');
        setTimeout(() => document.body.removeChild(overlay), 300);
        if (onCancel) onCancel();
      }
    });
  }
}