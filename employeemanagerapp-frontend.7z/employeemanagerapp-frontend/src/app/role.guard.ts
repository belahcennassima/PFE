import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(
    private router: Router,
    private authService: AuthService
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const currentUser = this.authService.currentUserValue;
    
    if (currentUser) {
      // Vérifier si le rôle requis correspond
      if (route.data['role'] && route.data['role'] !== currentUser.role) {
        // Rôle non autorisé, rediriger vers la page appropriée
        if (currentUser.role === 'HR') {
          this.router.navigate(['/hr-dashboard']);
        } else {
          this.router.navigate(['/user-dashboard']);
        }
        return false;
      }
      
      // Autorisé
      return true;
    }

    // Pas connecté, rediriger vers login
    this.router.navigate(['/login']);
    return false;
  }
}