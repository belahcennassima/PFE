import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { AttendanceService } from '../../attendance.service';
import { LeaveRequestService } from '../../leave-request.service';
import { ThemeService } from '../../theme.service';
import { Employee } from '../../employee';
import { Attendance } from '../../attendance';
import { LeaveRequest } from '../../leave-request';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { ChartConfiguration, ChartData } from 'chart.js';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable'

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  currentEmployee: Employee | null = null;
  attendances: Attendance[] = [];
  leaveRequests: LeaveRequest[] = [];
  isLoading: boolean = true;
  isDarkMode: boolean = false;
  
  // Statistiques
  totalPresent: number = 0;
  totalAbsent: number = 0;
  totalConge: number = 0;
  totalMaladie: number = 0;
  totalHours: number = 0;
  averageHoursPerDay: number = 0;
  
  // Nouvelle présence
  newAttendance: Attendance = {
    employeeId: 0,
    date: '',
    status: 'PRESENT'
  };
  
  // Nouvelle demande de congé
  newLeaveRequest: LeaveRequest = {
    employeeId: 0,
    startDate: '',
    endDate: '',
    type: 'ANNUAL',
    status: 'PENDING'
  };
  
  // Configuration du graphique
  public chartData: ChartData = {
    labels: ['Présent', 'Absent', 'Congé', 'Maladie'],
    datasets: [{
      data: [0, 0, 0, 0],
      backgroundColor: ['#28a745', '#dc3545', '#ffc107', '#17a2b8']
    }]
  };
  
  public chartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  };

  constructor(
    private authService: AuthService,
    private attendanceService: AttendanceService,
    private leaveRequestService: LeaveRequestService,
    private themeService: ThemeService,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    console.log('UserDashboard ngOnInit called');
    this.currentEmployee = this.authService.currentEmployeeValue;
    console.log('Current employee:', this.currentEmployee);
  
    if (!this.currentEmployee) {
      console.log('No employee found, redirecting to login');
      this.router.navigate(['/login']);
      return;
    }

    this.themeService.darkMode$.subscribe(isDark => {
      this.isDarkMode = isDark;
    });

  this.loadData();
}

  loadData(): void {
    this.loadAttendances();
    this.loadLeaveRequests();
  }

  loadAttendances(): void {
    this.isLoading = true;
    const employeeId = this.currentEmployee?.id;
    
    if (employeeId) {
      this.attendanceService.getAttendanceByEmployee(employeeId).subscribe(
        (response: Attendance[]) => {
          this.attendances = response.sort((a, b) => 
            new Date(b.date).getTime() - new Date(a.date).getTime()
          );
          this.calculateStatistics();
          this.updateChart();
          this.isLoading = false;
          this.toastr.success('Données chargées avec succès', 'Succès');
        },
        (error: HttpErrorResponse) => {
          this.toastr.error('Erreur lors du chargement des présences', 'Erreur');
          this.isLoading = false;
        }
      );
    }
  }

  loadLeaveRequests(): void {
    const employeeId = this.currentEmployee?.id;
    if (employeeId) {
      this.leaveRequestService.getLeaveRequestsByEmployee(employeeId).subscribe(
        (response: LeaveRequest[]) => {
          this.leaveRequests = response.sort((a, b) => 
            new Date(b.startDate).getTime() - new Date(a.startDate).getTime()
          );
        },
        (error: HttpErrorResponse) => {
          this.toastr.error('Erreur lors du chargement des demandes', 'Erreur');
        }
      );
    }
  }

  calculateStatistics(): void {
    this.totalPresent = this.attendances.filter(a => a.status === 'PRESENT').length;
    this.totalAbsent = this.attendances.filter(a => a.status === 'ABSENT').length;
    this.totalConge = this.attendances.filter(a => a.status === 'CONGE').length;
    this.totalMaladie = this.attendances.filter(a => a.status === 'MALADIE').length;
    
    // Calcul des heures
    this.totalHours = 0;
    let daysWithHours = 0;
    
    this.attendances.forEach(att => {
      if (att.checkInTime && att.checkOutTime) {
        const hours = this.calculateHours(att.checkInTime, att.checkOutTime);
        this.totalHours += hours;
        daysWithHours++;
      }
    });
    
    this.averageHoursPerDay = daysWithHours > 0 ? this.totalHours / daysWithHours : 0;
  }

  calculateHours(checkIn: string, checkOut: string): number {
    const [inHours, inMinutes] = checkIn.split(':').map(Number);
    const [outHours, outMinutes] = checkOut.split(':').map(Number);
    
    const inTotalMinutes = inHours * 60 + inMinutes;
    const outTotalMinutes = outHours * 60 + outMinutes;
    
    return (outTotalMinutes - inTotalMinutes) / 60;
  }

  updateChart(): void {
    this.chartData = {
      labels: ['Présent', 'Absent', 'Congé', 'Maladie'],
      datasets: [{
        data: [this.totalPresent, this.totalAbsent, this.totalConge, this.totalMaladie],
        backgroundColor: ['#28a745', '#dc3545', '#ffc107', '#17a2b8']
      }]
    };
  }

  onAddAttendance(): void {
    this.newAttendance.employeeId = this.currentEmployee!.id;
    
    this.attendanceService.addAttendance(this.newAttendance).subscribe(
      (response: Attendance) => {
        this.loadAttendances();
        this.newAttendance = {
          employeeId: this.currentEmployee!.id,
          date: '',
          status: 'PRESENT'
        };
        document.getElementById('close-attendance-modal')?.click();
        this.toastr.success('Présence ajoutée avec succès', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors de l\'ajout de la présence', 'Erreur');
      }
    );
  }

  onAddLeaveRequest(): void {
    this.newLeaveRequest.employeeId = this.currentEmployee!.id;
    
    this.leaveRequestService.addLeaveRequest(this.newLeaveRequest).subscribe(
      (response: LeaveRequest) => {
        this.loadLeaveRequests();
        this.newLeaveRequest = {
          employeeId: this.currentEmployee!.id,
          startDate: '',
          endDate: '',
          type: 'ANNUAL',
          status: 'PENDING'
        };
        document.getElementById('close-leave-modal')?.click();
        this.toastr.success('Demande de congé envoyée', 'Succès');
      },
      (error: HttpErrorResponse) => {
        this.toastr.error('Erreur lors de l\'envoi de la demande', 'Erreur');
      }
    );
  }

  exportToPDF(): void {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text('Rapport de Présences', 14, 22);
    doc.setFontSize(12);
    doc.text(`Employé: ${this.currentEmployee?.name}`, 14, 32);
    
    const tableData = this.attendances.map(att => [
      att.date,
      att.status,
      att.checkInTime || '-',
      att.checkOutTime || '-',
      att.notes || '-'
    ]);
    
    (doc as any).autoTable( {
      startY: 40,
      head: [['Date', 'Statut', 'Entrée', 'Sortie', 'Notes']],
      body: tableData
    });
    
    doc.save(`presences_${this.currentEmployee?.name}.pdf`);
    this.toastr.success('PDF exporté avec succès', 'Export');
  }

  exportToExcel(): void {
    const worksheet = XLSX.utils.json_to_sheet(
      this.attendances.map(att => ({
        'Date': att.date,
        'Statut': att.status,
        'Heure Entrée': att.checkInTime || '-',
        'Heure Sortie': att.checkOutTime || '-',
        'Notes': att.notes || '-'
      }))
    );
    
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Présences');
    
    XLSX.writeFile(workbook, `presences_${this.currentEmployee?.name}.xlsx`);
    this.toastr.success('Excel exporté avec succès', 'Export');
  }

  getStatusBadgeClass(status: string): string {
    switch(status) {
      case 'PRESENT': return 'badge-success';
      case 'ABSENT': return 'badge-danger';
      case 'CONGE': return 'badge-warning';
      case 'MALADIE': return 'badge-info';
      case 'PENDING': return 'badge-warning';
      case 'APPROVED': return 'badge-success';
      case 'REJECTED': return 'badge-danger';
      default: return 'badge-secondary';
    }
  }

  getLeaveTypeLabel(type: string): string {
    switch(type) {
      case 'ANNUAL': return 'Congé annuel';
      case 'SICK': return 'Congé maladie';
      case 'UNPAID': return 'Congé sans solde';
      default: return type;
    }
  }

  toggleTheme(): void {
    this.themeService.toggleTheme();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}