import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Attendance } from './attendance';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {
  private apiServerUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) { }

  public getAllAttendances(): Observable<Attendance[]> {
    return this.http.get<Attendance[]>(`${this.apiServerUrl}/api/attendance/all`);
  }

  public getAttendanceByEmployee(employeeId: number): Observable<Attendance[]> {
    return this.http.get<Attendance[]>(`${this.apiServerUrl}/api/attendance/employee/${employeeId}`);
  }

  public getAttendanceByEmployeeAndDateRange(employeeId: number, startDate: string, endDate: string): Observable<Attendance[]> {
    return this.http.get<Attendance[]>(
      `${this.apiServerUrl}/api/attendance/employee/${employeeId}/range?startDate=${startDate}&endDate=${endDate}`
    );
  }

  public addAttendance(attendance: Attendance): Observable<Attendance> {
    return this.http.post<Attendance>(`${this.apiServerUrl}/api/attendance/add`, attendance);
  }

  public updateAttendance(attendance: Attendance): Observable<Attendance> {
    return this.http.put<Attendance>(`${this.apiServerUrl}/api/attendance/update`, attendance);
  }

  public deleteAttendance(attendanceId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerUrl}/api/attendance/delete/${attendanceId}`);
  }
}