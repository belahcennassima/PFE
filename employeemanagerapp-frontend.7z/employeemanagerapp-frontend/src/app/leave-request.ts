export interface LeaveRequest {
  id?: number;
  employeeId: number;
  startDate: string;
  endDate: string;
  type: string; // 'ANNUAL', 'SICK', 'UNPAID'
  status: string; // 'PENDING', 'APPROVED', 'REJECTED'
  reason?: string;
  hrComment?: string;
}