import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LeaveRequest } from './leave-request';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LeaveRequestService {
  private apiServerUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) { }

  public getAllLeaveRequests(): Observable<LeaveRequest[]> {
    return this.http.get<LeaveRequest[]>(`${this.apiServerUrl}/api/leave-requests/all`);
  }

  public getLeaveRequestsByEmployee(employeeId: number): Observable<LeaveRequest[]> {
    return this.http.get<LeaveRequest[]>(`${this.apiServerUrl}/api/leave-requests/employee/${employeeId}`);
  }

  public getPendingLeaveRequests(): Observable<LeaveRequest[]> {
    return this.http.get<LeaveRequest[]>(`${this.apiServerUrl}/api/leave-requests/pending`);
  }

  public addLeaveRequest(leaveRequest: LeaveRequest): Observable<LeaveRequest> {
    return this.http.post<LeaveRequest>(`${this.apiServerUrl}/api/leave-requests/add`, leaveRequest);
  }

  public updateLeaveRequest(leaveRequest: LeaveRequest): Observable<LeaveRequest> {
    return this.http.put<LeaveRequest>(`${this.apiServerUrl}/api/leave-requests/update`, leaveRequest);
  }

  public deleteLeaveRequest(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerUrl}/api/leave-requests/delete/${id}`);
  }
}